package ece325.labs.lab2;

/** 
 * Finish this class.
 */
public class Chair extends Furniture{
	//change the type field in Equipment superclass
	public Chair() {
		type = "Chair";
	}
}
