package ece325.labs.lab2;

/** 
 * Finish this class.
 */
public class Stool extends Furniture{
	//change the type field in Equipment superclass
	public Stool() {
		type = "Stool";
	}
	
	
}
