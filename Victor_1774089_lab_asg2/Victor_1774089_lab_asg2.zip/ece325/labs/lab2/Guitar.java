package ece325.labs.lab2;

/** 
 * Finish this class.
 */
public class Guitar extends Instrument{
	//change the type field in Equipment superclass
	public Guitar() {
		type = "Guitar";
	}
}
