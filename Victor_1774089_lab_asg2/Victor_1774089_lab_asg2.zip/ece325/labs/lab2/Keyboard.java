package ece325.labs.lab2;

/** 
 * Finish this class.
 */
public class Keyboard extends Instrument{
	//change the type field in Equipment superclass
	public Keyboard() {
		type = "Keyboard";
	}
}
