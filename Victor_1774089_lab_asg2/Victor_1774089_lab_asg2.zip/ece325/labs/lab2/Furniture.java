package ece325.labs.lab2;

/** 
 * Finish this class.
 */
public class Furniture extends Equipment{
	//this class is a subclass of equipment and superclass of chair and stool
}
